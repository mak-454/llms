"""[BETA] Functionality relating to evaluation."""
